package es.ucm.fdi;

import es.ucm.fdi.integracion.DAOChatImp;
import es.ucm.fdi.integracion.DAOFactory;
import es.ucm.fdi.integracion.DAOFactoryImp;
import es.ucm.fdi.integracion.TOChat;
import es.ucm.fdi.integracion.TOSesion;
import es.ucm.fdi.integracion.TOUsuario;
import es.ucm.fdi.integracion.TOPendiente.tPendiente;
import es.ucm.fdi.negocio.ASGestionCuentasImp;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class PruebaEliminarCuenta extends TestCase {
	
	
	public  static Test suite() {
		return new TestSuite(PruebaEliminarCuenta.class);
	}
	
	public void testCuentaEliminada(){
		
		DAOFactory fd = new DAOFactoryImp();
		
		DAOChatImp daoChat = fd.generaDAOChat();
		
		ASGestionCuentasImp as = new ASGestionCuentasImp(fd.generaDAOUsuario(),fd.generaDAOSesion(),fd.generaDAOChat());		
		//Cuenta de borraremos
		as.crearCuenta("usuarioPrueba", "usuarioPrueba@ucm.es", "contrasena","foto","desc");
		TOUsuario usuarioPrueba = as.getUsuarioDAO().read("usuarioPrueba@ucm.es");
		TOSesion sesion = as.iniciarSesion("usuarioPrueba@ucm.es", "contrasena");

		// esta en su lista de conocidos
		as.crearCuenta("conocido1", "conocido1@ucm.es", "contrasena1","foto","desc");
		TOUsuario conocido1 = as.getUsuarioDAO().read("conocido1@ucm.es");
		as.getUsuarioDAO().anadirConocido(conocido1, "usuarioPrueba@ucm.es");
		
		// esta en su lista de pendientes (tipo recibo). UsuarioPrueba dio Me gusta primero
		as.crearCuenta("pendiente1", "pendiente1@ucm.es", "contrasena1","foto","desc");
		TOUsuario pendiente1 = as.getUsuarioDAO().read("pendiente1@ucm.es");
		as.getUsuarioDAO().anadirPendiente(usuarioPrueba, "pendiente1@ucm.es", tPendiente.MANDO);
		as.getUsuarioDAO().anadirPendiente(pendiente1, "usuarioPrueba@ucm.es", tPendiente.RECIBO);
	
		// esta en su lista de pendientes (tipo mando) pendiente2 dio Me gusta primero
		as.crearCuenta("pendiente2", "pendiente2@ucm.es", "contrasena2","foto","desc");
		TOUsuario pendiente2 = as.getUsuarioDAO().read("pendiente2@ucm.es");
		as.getUsuarioDAO().anadirPendiente(pendiente2, "usuarioPrueba@ucm.es", tPendiente.MANDO);
		as.getUsuarioDAO().anadirPendiente(usuarioPrueba, "pendiente1@ucm.es", tPendiente.RECIBO);
		
		// esta en la lista de chats
		as.crearCuenta("chat", "chat@ucm.es", "chat","foto","desc");
		TOUsuario pendiente3 = as.getUsuarioDAO().read("chat@ucm.es");
		
		TOChat chat = daoChat.createChat(pendiente3.getCorreo(), usuarioPrueba.getCorreo());
		
		as.getUsuarioDAO().añadirChatIdVector(pendiente3,chat.getChatid());
		as.getUsuarioDAO().añadirChatIdVector(usuarioPrueba,chat.getChatid());
		
		as.eliminarCuenta(usuarioPrueba,sesion);
		
//		TOUsuario resultado = as.getUsuarioDAO().read(usuarioPrueba.getCorreo());

		assertTrue("No se ha borrado el usuario" ,as.getUsuarioDAO().read(usuarioPrueba.getCorreo()) == null);
		
		//Comprobamos que se ha hecho correctamente examinando las listas de los usuarios
		
		int i = 0;
		boolean encontrado= false;
		String aux;
		
		//conocidos
		while (i < conocido1.getListaConocidos().size() && !encontrado ){

			aux = conocido1.getListaConocidos().get(i);
			System.out.println(aux);
			
			if (aux.equalsIgnoreCase("usuarioPrueba@ucm.es")) encontrado = true;
			++i;
		}
	
		assertTrue("usuarioPrueba sigue en la lista de conocidos" , encontrado);
		
		while (i < pendiente1.getListaPendientes().size() && !encontrado ){

			aux = pendiente1.getListaPendientes().get(i).getCorreo();
			System.out.println(aux);
			
			if (aux.equalsIgnoreCase("usuarioPrueba@ucm.es")) encontrado = true;
			++i;
		}
	
		assertTrue("usuarioPrueba sigue en la lista de pendientes1" , encontrado);
		
		while (i < pendiente2.getListaPendientes().size() && !encontrado ){

			aux = pendiente2.getListaPendientes().get(i).getCorreo();
			System.out.println(aux);
			
			if (aux.equalsIgnoreCase("usuarioPrueba@ucm.es")) encontrado = true;
			++i;
		}
	
		assertTrue("usuarioPrueba sigue en la lista de pendientes2" , encontrado);
		
//		while (i < pendiente3.getChats().size() && !encontrado) {
//
//			aux = pendiente3.getChats();
//			System.out.println(aux);
//
//			if (aux.equalsIgnoreCase("usuarioPrueba@ucm.es"))
//				encontrado = true;
//			++i;
//		}
//
//		assertTrue("usuarioPrueba sigue en la lista de pendientes3", encontrado);

	}
}
	