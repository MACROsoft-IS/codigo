package es.ucm.fdi;

import es.ucm.fdi.integracion.DAOChatImp;
import es.ucm.fdi.integracion.DAOFactory;
import es.ucm.fdi.integracion.DAOFactoryImp;
import es.ucm.fdi.integracion.DAOMensajeImp;
import es.ucm.fdi.integracion.DAOSesionImp;
import es.ucm.fdi.integracion.DAOUsuarioImp;
import es.ucm.fdi.integracion.TOChat;
import es.ucm.fdi.integracion.TOMensaje;
import es.ucm.fdi.integracion.TOUsuario;
import es.ucm.fdi.negocio.ASGestionChatsImp;
import es.ucm.fdi.negocio.ASGestionCuentasImp;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class PruebaChat extends TestCase {

	public  static Test suite() {
		return new TestSuite(PruebaChat.class);
	}
	
	public void testChat(){
		
		DAOFactory fd = new DAOFactoryImp();

		DAOUsuarioImp daoUsuario = fd.generaDAOUsuario();
		DAOSesionImp daoSesion = fd.generaDAOSesion();
		DAOChatImp daoChat = fd.generaDAOChat();
		DAOMensajeImp daoMensaje = fd.generaDAOMensaje();
		
		TOChat chat;
		
		ASGestionCuentasImp as = new ASGestionCuentasImp(daoUsuario, daoSesion, daoChat);
		ASGestionChatsImp achat = new ASGestionChatsImp(daoUsuario, daoSesion, daoChat, daoMensaje);
		
		as.crearCuenta("nombre1", "correo1@ucm.es", "contrasena1","foto","desc");
		as.crearCuenta("nombre2", "correo2@ucm.es", "contrasena2","foto","desc");
		as.crearCuenta("nombre3", "correo3@ucm.es", "contrasena3","foto","desc");
		as.crearCuenta("nombre4", "correo4@ucm.es", "contrasena4","foto","desc");
		as.iniciarSesion("correo1@ucm.es","contraseña1");
		
		assertTrue("La lista de chats debe estar vacía \n", as.getUsuarioDAO().read("correo1@ucm.es").getChats().isEmpty());

		TOUsuario uno = as.getUsuarioDAO().read("correo1@ucm.es");
		TOUsuario dos = as.getUsuarioDAO().read("correo2@ucm.es");
		TOUsuario tres = as.getUsuarioDAO().read("correo3@ucm.es");
		TOUsuario cuatro = as.getUsuarioDAO().read("correo4@ucm.es");
		
		daoUsuario.anadirConocido(uno, "correo2@ucm.es");
		daoUsuario.anadirConocido(dos, "correo1@ucm.es");
		chat = daoChat.createChat("correo2@ucm.es", "correo1@ucm.es");
		daoUsuario.añadirChatIdVector(uno, chat.getChatid());
		daoUsuario.añadirChatIdVector(dos, chat.getChatid());
		
		daoUsuario.anadirConocido(uno, "correo3@ucm.es");
		daoUsuario.anadirConocido(tres, "correo1@ucm.es");
		chat = daoChat.createChat("correo3@ucm.es", "correo1@ucm.es");
		daoUsuario.añadirChatIdVector(uno, chat.getChatid());
		daoUsuario.añadirChatIdVector(tres, chat.getChatid());
		
		daoUsuario.anadirConocido(uno, "correo4@ucm.es");
		daoUsuario.anadirConocido(cuatro, "correo1@ucm.es");
		chat = daoChat.createChat("correo4@ucm.es", "correo1@ucm.es");
		daoUsuario.añadirChatIdVector(uno, chat.getChatid());
		daoUsuario.añadirChatIdVector(cuatro, chat.getChatid());
		
		daoUsuario.anadirConocido(dos, "correo3@ucm.es");
		daoUsuario.anadirConocido(tres, "correo2@ucm.es");
		chat = daoChat.createChat("correo3@ucm.es", "correo2@ucm.es");
		daoUsuario.añadirChatIdVector(dos, chat.getChatid());
		daoUsuario.añadirChatIdVector(tres, chat.getChatid());
		
		daoUsuario.anadirConocido(dos, "correo4@ucm.es");
		daoUsuario.anadirConocido(cuatro, "correo2@ucm.es");
		chat = daoChat.createChat("correo4@ucm.es", "correo2@ucm.es");
		daoUsuario.añadirChatIdVector(dos, chat.getChatid());
		daoUsuario.añadirChatIdVector(cuatro, chat.getChatid());

		daoUsuario.anadirConocido(tres, "correo4@ucm.es");
		daoUsuario.anadirConocido(cuatro, "correo3@ucm.es");
		chat = daoChat.createChat("correo4@ucm.es", "correo3@ucm.es");
		daoUsuario.añadirChatIdVector(tres, chat.getChatid());
		daoUsuario.añadirChatIdVector(cuatro, chat.getChatid());
		
		
		int ok1 = 0;
		int ok2 = 0;
		int ok3 = 0;
		int ok4 = 0;
		
		for(int i = 0; i < uno.getChats().size(); i++){
			chat = daoChat.readChat(uno.getChats().get(i));
			if ((chat.getCorreoA().equalsIgnoreCase(uno.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(dos.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(dos.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(uno.getCorreo())))
					ok1++;
			if ((chat.getCorreoA().equalsIgnoreCase(uno.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(tres.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(tres.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(uno.getCorreo())))
					ok1++;
			if ((chat.getCorreoA().equalsIgnoreCase(uno.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(cuatro.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(cuatro.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(uno.getCorreo())))
					ok1++;
		}
		
		assertTrue("El usuario 1 debería tener 3 chats. \n", ok1 == 3);
		
		for(int i = 0; i < dos.getChats().size(); i++){
			chat = daoChat.readChat(dos.getChats().get(i));
			if ((chat.getCorreoA().equalsIgnoreCase(dos.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(uno.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(uno.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(dos.getCorreo())))
					ok2++;
			if ((chat.getCorreoA().equalsIgnoreCase(dos.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(tres.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(tres.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(dos.getCorreo())))
					ok2++;
			if ((chat.getCorreoA().equalsIgnoreCase(dos.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(cuatro.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(cuatro.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(dos.getCorreo())))
					ok2++;
		}
		
		assertTrue("El usuario 2 debería tener 3 chats. \n", ok2 == 3);
		
		for(int i = 0; i < tres.getChats().size(); i++){
			chat = daoChat.readChat(tres.getChats().get(i));
			if ((chat.getCorreoA().equalsIgnoreCase(tres.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(uno.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(uno.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(tres.getCorreo())))
					ok3++;
			if ((chat.getCorreoA().equalsIgnoreCase(tres.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(dos.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(dos.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(tres.getCorreo())))
					ok3++;
			if ((chat.getCorreoA().equalsIgnoreCase(tres.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(cuatro.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(cuatro.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(tres.getCorreo())))
					ok3++;
		}
		
		assertTrue("El usuario 3 debería tener 3 chats. \n", ok3 == 3);
		
		for(int i = 0; i < cuatro.getChats().size(); i++){
			chat = daoChat.readChat(cuatro.getChats().get(i));
			if ((chat.getCorreoA().equalsIgnoreCase(cuatro.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(uno.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(uno.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(cuatro.getCorreo())))
					ok4++;
			if ((chat.getCorreoA().equalsIgnoreCase(cuatro.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(dos.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(dos.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(cuatro.getCorreo())))
					ok4++;
			if ((chat.getCorreoA().equalsIgnoreCase(cuatro.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(tres.getCorreo()))
					|| (chat.getCorreoA().equalsIgnoreCase(tres.getCorreo()) && chat.getCorreoB().equalsIgnoreCase(cuatro.getCorreo())))
					ok4++;
		}
		
		assertTrue("El usuario 4 debería tener 3 chats. \n", ok4 == 3);
		
		
		chat = achat.salaChat(uno.getChats(), uno, dos);
		String mensaje = "Hola";
		achat.crearMsj(chat, uno, mensaje);
		int j = 0;
		boolean encontrado = false;
		TOMensaje tMensaje;
		while (j < chat.getMensajes().size() && !encontrado){
			tMensaje = daoMensaje.read(chat.getMensajes().get(j));
			if (tMensaje.getContenido().equalsIgnoreCase(mensaje))
				encontrado = true;
			j++;
		}
		
		assertTrue("El mensaje debe estar en los chats de cada usuario \n" , encontrado);
		
		chat = achat.salaChat(uno.getChats(), uno, dos);
		String idChat1 = chat.getChatid();
		daoChat.removeChat(idChat1);
		daoUsuario.eliminarChatIdVector(uno, idChat1);
		daoUsuario.eliminarChatIdVector(dos, idChat1);
		
		chat = achat.salaChat(uno.getChats(), uno, tres);
		String idChat2 = chat.getChatid();
		daoChat.removeChat(idChat2);
		daoUsuario.eliminarChatIdVector(uno, idChat2);
		daoUsuario.eliminarChatIdVector(tres, idChat2);
		
		chat = achat.salaChat(uno.getChats(), uno, cuatro);
		String idChat3 = chat.getChatid();
		daoChat.removeChat(idChat3);
		daoUsuario.eliminarChatIdVector(uno, idChat3);
		daoUsuario.eliminarChatIdVector(cuatro, idChat3);
		
		
		assertTrue("El usuario 1 no deberia tener chats abiertos \n", uno.getChats().isEmpty());
		
		int c = 0;
		int x = 0;
		boolean tresSi = false;
		boolean cuatroSi = false;
		String idChat34 = null;
		String idChat43 = null;
		TOChat chato;
		while(c < tres.getChats().size() && !tresSi){
			chato = daoChat.readChat(tres.getChats().get(c));
			if ((chato.getCorreoA().equalsIgnoreCase(tres.getCorreo()) && chato.getCorreoB().equalsIgnoreCase(cuatro.getCorreo()))
					|| (chato.getCorreoA().equalsIgnoreCase(cuatro.getCorreo()) && chato.getCorreoB().equalsIgnoreCase(tres.getCorreo())))
			{
				tresSi = true;
				idChat34 = tres.getChats().get(c);
			}
			c++;
		}
		
		while(x < cuatro.getChats().size() && !cuatroSi){
			chato = daoChat.readChat(cuatro.getChats().get(x));
			if ((chato.getCorreoA().equalsIgnoreCase(tres.getCorreo()) && chato.getCorreoB().equalsIgnoreCase(cuatro.getCorreo()))
					|| (chato.getCorreoA().equalsIgnoreCase(cuatro.getCorreo()) && chato.getCorreoB().equalsIgnoreCase(tres.getCorreo())))
			{
				cuatroSi = true;
				idChat43 = cuatro.getChats().get(x);
			}
			x++;
		}
		TOChat tresycuatro = daoChat.readChat(idChat34);
		TOChat cuatroytres = daoChat.readChat(idChat43);
		
		assertTrue("Debe estar el chat del 4 en el 3 y el 3 en el 4 \n", tresSi && cuatroSi && tresycuatro.equals(cuatroytres));
	}
	
}
