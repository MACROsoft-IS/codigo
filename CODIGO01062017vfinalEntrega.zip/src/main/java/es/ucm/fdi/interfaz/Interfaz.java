package es.ucm.fdi.interfaz;

public class Interfaz {

	public static void notificar(String mensaje){
		System.out.println(mensaje);
	}
}
