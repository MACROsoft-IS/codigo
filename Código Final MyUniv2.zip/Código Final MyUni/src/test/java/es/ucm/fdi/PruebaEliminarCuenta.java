package es.ucm.fdi;

import java.nio.channels.AcceptPendingException;

import es.ucm.fdi.integracion.DAOFactory;
import es.ucm.fdi.integracion.DAOFactoryImp;
import es.ucm.fdi.integracion.DAOUsuario;
import es.ucm.fdi.integracion.TOSesion;
import es.ucm.fdi.integracion.TOUsuario;
import es.ucm.fdi.integracion.TOPendiente.tPendiente;
import es.ucm.fdi.negocio.ASGestionConocerImp;
import es.ucm.fdi.negocio.ASGestionCuentasImp;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class PruebaEliminarCuenta extends TestCase {
	
	
	public  static Test suite() {
		return new TestSuite(PruebaEliminarCuenta.class);
	}
	
	public void testCuentaEliminada(){
		
		DAOFactory fd = new DAOFactoryImp();
		
		ASGestionCuentasImp as = new ASGestionCuentasImp(fd.generaDAOUsuario(),fd.generaDAOSesion(),fd.generaDAOChat());
		ASGestionConocerImp ac = new ASGestionConocerImp(fd.generaDAOUsuario(),fd.generaDAOChat());
		
		int i = 0;
		boolean encontrado= false;
		String[] aux;
		String aux2;
		
		//Creamos las cuentas para la prueba
		as.crearCuenta("borrar", "borrar@ucm.es", "contrasena1","foto","desc");
		as.crearCuenta("conocido1", "conocido1@ucm.es", "contrasena2","foto","desc");
		as.crearCuenta("conocido2", "conocido2@ucm.es", "contrasena2","foto","desc");
		as.crearCuenta("pendiente1", "pendiente1@ucm.es", "contrasena2","foto","desc");
		as.crearCuenta("pendiente2", "pendiente2@ucm.es", "contrasena2","foto","desc");
		as.crearCuenta("pendiente3", "pendiente3@ucm.es", "contrasena2","foto","desc");
		as.crearCuenta("pendiente4", "pendiente4@ucm.es", "contrasena2","foto","desc");
		//System.out.println(ASGestionCuentaImp.bdCadenas);
		
		//Añadimos conocidos, chats y pendientes a "borrar".
		TOUsuario borrar = as.getUsuarioDAO().read("borrar@ucm.es");
		//Añadimos conocidos y chats a "conocido"
		TOUsuario conocido1 = as.getUsuarioDAO().read("conocido1@ucm.es");
		TOUsuario conocido2 = as.getUsuarioDAO().read("conocido2@ucm.es");
		TOUsuario pendiente1 = as.getUsuarioDAO().read("pendiente1@ucm.es");
		TOUsuario pendiente2 = as.getUsuarioDAO().read("pendiente2@ucm.es");
		TOUsuario pendiente3 = as.getUsuarioDAO().read("pendiente3@ucm.es");
		TOUsuario pendiente4 = as.getUsuarioDAO().read("pendiente4@ucm.es");
		ac.AplicarOpcion(borrar, conocido1, 1, true);
		ac.AplicarOpcion(borrar, conocido2, 1, true);
		ac.AplicarOpcion(pendiente4, borrar, 1, false);

		
		//Comprobamos que se ha hecho correctamente
		while (i < conocido2.getChats().size() && !encontrado ){
		
			aux=conocido2.getChats().get(i).split("/");
			System.out.println(aux[1]);
			if(aux[1].equalsIgnoreCase("borrar@ucm.es")) encontrado = true;
			++i;
		}
			
					
		
		assertTrue("Borrar sigue en la lista de chats" , encontrado);
		assertTrue("Desconocido no se ha añadido a la lista de conocidos" , conocido2.getListaConocidos().contains("borrar@ucm.es"));
		
//		//Añadimos conocidos y chats a "pendiente
//		
//		//Miramos si se ha hecho correctamente
		i = 0;
		encontrado=false;
		while (i < pendiente4.getListaPendientes().size() && !encontrado ){
			
			aux2=conocido2.getListaPendientes().get(i).getCorreo();
			System.out.println(aux2);
			if(aux2.equalsIgnoreCase("borrar@ucm.es")) encontrado = true;
			++i;
		}
			
					
		
		assertTrue("Borrar sigue en la lista de pendientes" , encontrado);
//		
//		
//		//Eliminamos la cuenta
//		
//		TOSesion sesion = as.iniciarSesion("borrar@ucm.es", "contrasena1");
//		as.eliminarCuenta(sesion.getCuentaActiva(), sesion);
//		assertTrue("La cuenta todavia existe \n" + as.getUsuarioDAO().getBdUsersConnection(), as.iniciarSesion("borrar@ucm.es", "contrasena1") == null);
//		assertFalse("Las otras cuentas no existen \n" + as.getUsuarioDAO().getBdUsersConnection(), as.iniciarSesion("conocido1@ucm.es", "contrasena2") == null);
//		
//		
//		
//		
//		//Miramos de nuevo la lista de conocidos y de chats de "conocido2"
//		i = 0;
//		while (i < conocido2.getChats().size() &&
//				!conocido2.getChats().get(i).getCorreo().equalsIgnoreCase("borrar@ucm.es") ) 
//				 {++i;}
//			
//					
//		
//		assertFalse("Borrar sigue en la lista de chats" , i < conocido2.getChats().size());
//		assertFalse("Borrar sigue en la lista de conocidos" , conocido2.getListaConocidos().contains("borrar@ucm.es"));
//		
//		
//		//Miramos de nuevo la lista de pendientes de "pendiente4"
//		i = 0;
//		while (i < pendiente4.getListaPendientes().size() &&
//				!pendiente4.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("borrar@ucm.es") ) 
//				 {++i;}
//			
//					
//		
//		assertFalse("Borrar sigue en la lista de pendientes" , i < pendiente4.getListaPendientes().size());
	}
	
	
}
	