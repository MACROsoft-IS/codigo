package es.ucm.fdi;

import es.ucm.fdi.integracion.DAOFactory;
import es.ucm.fdi.integracion.DAOFactoryImp;
import es.ucm.fdi.negocio.ASGestionCuentasImp;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class PruebaCrearCuenta extends TestCase {

	/**
	 * @return the suite of tests being tested
	 */
	public  static Test suite() {
		return new TestSuite(PruebaCrearCuenta.class);
	}
	
	public void testCrearCuenta(){
		DAOFactory fd = new DAOFactoryImp();
		ASGestionCuentasImp as = new ASGestionCuentasImp(fd.generaDAOUsuario(),fd.generaDAOSesion(),fd.generaDAOChat());
		  
		  //Comprobamos que la base de datos esté vacía al iniciar
		  assertTrue("La BD debía estar vacía y tiene elementos.Contenido actual \n" + as.getUsuarioDAO().getBdUsersConnection(), as.getUsuarioDAO().getBdUsersConnection().getIds().isEmpty());
		  
		  //Creamos dos cuentas sobre las que se van a realizar las pruebas y comprobamos que la base de datos las almacene bien
		  as.crearCuenta("nombre1", "correo1@ucm.es", "contrasena1","foto","description");
		  assertTrue("La BD debe tener sólo un elemento. Contenido actual \n" + as.getUsuarioDAO().getBdUsersConnection(), as.getUsuarioDAO().getBdUsersConnection().getIds().size() == 1);
		  as.crearCuenta("nombre2", "correo2@ucm.es", "contrasena2","foto","description");
		  assertTrue("La BD debe tener dos elemento. Contenido actual \n"+ as.getUsuarioDAO().getBdUsersConnection(), as.getUsuarioDAO().getBdUsersConnection().getIds().size() == 2);

		  //Comprobamos que todos los datos se hayan guardado bien en la base de datos para usuario1
		  assertTrue("El usuario no existe en la base de datos", as.getUsuarioDAO().getBdUsersConnection().getIds().contains("correo1@ucm.es"));
		  assertTrue("El nombre del usuario1 no se ha guardado correctamente", as.getUsuarioDAO().getBdUsersConnection().find("correo1@ucm.es").getNombre() == "nombre1");
		  assertTrue("La contraseña del usuario1 no se ha guardado correctamente", as.getUsuarioDAO().getBdUsersConnection().find("correo1@ucm.es").getContrasena() == "contrasena1");
		  assertTrue("La foto del usuario1 no se ha guardado correctamente", as.getUsuarioDAO().getBdUsersConnection().find("correo1@ucm.es").getFoto() == "foto");
		  assertTrue("La descripción del usuario1 no se ha guardado correctamente", as.getUsuarioDAO().getBdUsersConnection().find("correo1@ucm.es").getDescripcion() == "description");
		  
		  //Comprobamos que todos los datos se hayan guardado bien en la base de datos para usuario2
		  assertTrue("El usuario no existe en la base de datos", as.getUsuarioDAO().getBdUsersConnection().getIds().contains("correo2@ucm.es"));
		  assertTrue("El nombre del usuario2 no se ha guardado correctamente", as.getUsuarioDAO().getBdUsersConnection().find("correo2@ucm.es").getNombre() == "nombre2");
		  assertTrue("La contraseña del usuario2 no se ha guardado correctamente", as.getUsuarioDAO().getBdUsersConnection().find("correo2@ucm.es").getContrasena() == "contrasena2");
		  assertTrue("La foto del usuario2 no se ha guardado correctamente", as.getUsuarioDAO().getBdUsersConnection().find("correo2@ucm.es").getFoto() == "foto");
		  assertTrue("La descripción del usuario2 no se ha guardado correctamente", as.getUsuarioDAO().getBdUsersConnection().find("correo2@ucm.es").getDescripcion() == "description");
	
	}
	
	public void testCampoVacio() {
		DAOFactory fd = new DAOFactoryImp();
		ASGestionCuentasImp as = new ASGestionCuentasImp(fd.generaDAOUsuario(),fd.generaDAOSesion(),fd.generaDAOChat());
		
		assertFalse("Se ha creado la cuenta sin el nombre \n" + as.getUsuarioDAO().getBdUsersConnection(), as.crearCuenta(null, "correo1@ucm.es", "contrasena1","foto","description"));
		
		assertFalse("Se ha creado la cuenta sin el correo \n" + as.getUsuarioDAO().getBdUsersConnection(), as.crearCuenta("nombre1", null, "contrasena1","foto","description"));
		
		assertFalse("Se ha creado la cuenta sin la contraseña \n" + as.getUsuarioDAO().getBdUsersConnection(), as.crearCuenta("nombre1", "correo1@ucm.es",null,"foto","description"));
		
		assertFalse("Se ha creado la cuenta sin la contraseña \n" + as.getUsuarioDAO().getBdUsersConnection(), as.crearCuenta("nombre1", "correo1@ucm.es","contrasena1",null,"description"));
		
		assertFalse("Se ha creado la cuenta sin la contraseña \n" + as.getUsuarioDAO().getBdUsersConnection(), as.crearCuenta("nombre1", "correo1@ucm.es","contrasena1","foto",null));
	}
	
	public void testCorreoRepetido() {
		DAOFactory fd = new DAOFactoryImp();
		ASGestionCuentasImp as = new ASGestionCuentasImp(fd.generaDAOUsuario(),fd.generaDAOSesion(),fd.generaDAOChat());
		
		as.crearCuenta("nombre1", "correo1@ucm.es", "contrasena1","foto","description");
		
		assertFalse("Se ha creado una cuenta con correo repetido \n" + as.getUsuarioDAO().getBdUsersConnection(), as.crearCuenta("nombre2", "correo1@ucm.es", "contrasena1",null,null));
		
	}
	
	public void testNombreRepetido() {
		DAOFactory fd = new DAOFactoryImp();
		ASGestionCuentasImp as = new ASGestionCuentasImp(fd.generaDAOUsuario(),fd.generaDAOSesion(),fd.generaDAOChat());
		
		as.crearCuenta("nombre1", "correo1@ucm.es", "contrasena1","foto","description");
		
		assertTrue("Se ha creado una cuenta sin nombre repetido \n" + as.getUsuarioDAO().getBdUsersConnection(), as.crearCuenta("nombre1", "correo2@ucm.es", "contrasena1","foto","description"));
		
	}
	
}
