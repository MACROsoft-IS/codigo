package es.ucm.fdi;

import java.util.ArrayList;
import java.util.Vector;

import es.ucm.fdi.datos.BDMemoria;
import es.ucm.fdi.integracion.DAOFactory;
import es.ucm.fdi.integracion.DAOFactoryImp;
import es.ucm.fdi.integracion.DAOUsuarioImp;
import es.ucm.fdi.integracion.TOChat;
import es.ucm.fdi.integracion.TOSesion;
import es.ucm.fdi.integracion.TOUsuario;
import es.ucm.fdi.negocio.ASGestionConocerImp;
import es.ucm.fdi.negocio.ASGestionCuentasImp;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class PruebaBloquearUsuario extends TestCase{

	/**
	 * @return the suite of tests being tested
	 */
	public  static Test suite() {
		return new TestSuite(PruebaBloquearUsuario.class);
	}
	
	public void testBloqueoUsuario(){
		//Creamos dos cuentas:
		DAOFactory fd = new DAOFactoryImp();
		ASGestionCuentasImp as = new ASGestionCuentasImp(fd.generaDAOUsuario(),fd.generaDAOSesion(),fd.generaDAOChat());
		ASGestionConocerImp ac = new ASGestionConocerImp(fd.generaDAOUsuario(), fd.generaDAOChat());
		TOChat chat;
		String[] UsuarioEncontrado = null;
		boolean encontrado1 = false;
		boolean encontrado2 = false;
		int i = 0;
		String correoUsuario;
		
		as.crearCuenta("usuario1","correousuario1","contrasena1","foto","desc");
		as.crearCuenta("usuario2","correousuario2","contrasena2","foto","desc");
		
		//Creamos las sesiones de ambas
		
		TOSesion sesionusuario1 = as.iniciarSesion("correousuario1","contrasena1");
		TOSesion sesionusuario2 = as.iniciarSesion("correousuario2","contrasena2");
		
		TOUsuario usuarioTO1 = sesionusuario1.getCuentaActiva();
		TOUsuario usuarioTO2 = sesionusuario2.getCuentaActiva();
		
		System.out.println(usuarioTO1.getCorreo());
		System.out.println(usuarioTO2.getCorreo());
	
		chat=as.getChatDAO().createChat(usuarioTO1.getCorreo(), usuarioTO2.getCorreo());
		
				
		as.getUsuarioDAO().añadirChatIdVector(usuarioTO1, usuarioTO1.getCorreo()+"/"+usuarioTO2.getCorreo());
		as.getUsuarioDAO().añadirChatIdVector(usuarioTO2, usuarioTO1.getCorreo()+"/"+usuarioTO2.getCorreo());
		
		System.out.println(usuarioTO1.getChats());
		System.out.println(usuarioTO2.getChats());
		
		Vector<String> listaChats1 = as.getUsuarioDAO().read("correousuario1").getChats();
		Vector<String> listaChats2 = as.getUsuarioDAO().read("correousuario2").getChats();
	
		//Mostramos las lista de chats de los dos usuarios
		for(i = 0; i<listaChats1.size(); i++){
			UsuarioEncontrado = listaChats1.get(i).split("/");
			System.out.println(UsuarioEncontrado[1]);
			if(UsuarioEncontrado[1].equalsIgnoreCase("correousuario2")){
				i=listaChats1.size();
			}
		}
		
		assertTrue("El usuario 2 se encuentra en las lista de chats del usuario 1 \n" + 
				as.getUsuarioDAO().getBdUsersConnection(), UsuarioEncontrado[1].equalsIgnoreCase("correousuario2"));

		i = 0;
		while (!encontrado2 && i < listaChats2.size()) {
			System.out.println(listaChats2.get(i));
			//chat = as.getChatDAO().readChat(listaChats2.get(i)); // Recibimos el chat i
			//System.out.println(as.getChatDAO().readChat(listaChats2.get(i)).getMensajesNuevosA());
			//System.out.println(as.getChatDAO().readChat(listaChats2.get(i)));
			System.out.println(chat.getCorreoA());
			correoUsuario = chat.getCorreoA(); // Sacamos el correo del chat i
			if (correoUsuario.equalsIgnoreCase("correousuario1")) encontrado2 = true;
			i++;
		}
		
		assertTrue("El usuario 1 se encuentra en las lista de chats del usuario 2  \n" + 
				as.getUsuarioDAO().getBdUsersConnection(), encontrado2);
		
		//usuario 1 bloque al usuario 2
		ac.AplicarOpcion(usuarioTO2, usuarioTO1, 3, false);

		
		//comprobamos que no estan en las listas
		
		encontrado1 = false;
		encontrado2 = false;
		i = 0;
		
		while (!encontrado1 && i < listaChats1.size()) {
			//chat = as.getChatDAO().readChat(listaChats1.get(i)); // Recibimos el chat i
			correoUsuario = chat.getCorreoB(); // Sacamos el correo del chat i
			System.out.println(chat.getCorreoB());
			if (correoUsuario.equalsIgnoreCase("correousuario2")) encontrado1 = true;
			i++;
		}
		
		assertTrue("El usuario 2 se encuentra en las lista de chats del usuario 1 \n" + 
				as.getUsuarioDAO().getBdUsersConnection(), encontrado1);
		i = 0;
		while (!encontrado2 && i < listaChats2.size()) {
			//chat = as.getChatDAO().readChat(listaChats2.get(i)); // Recibimos el chat i
			correoUsuario = chat.getCorreoA(); // Sacamos el correo del chat i
			if (correoUsuario == "correousuario1") encontrado2 = true;
			++i;
		}
		
		assertTrue("El usuario 1 se encuentra en las lista de chats del usuario 2  \n" + 
				as.getUsuarioDAO().getBdUsersConnection(), encontrado2);
		
	}
	
}
