package es.ucm.fdi.integracion;

public interface DAOChat {
	
	public TOChat createChat(String correoA, String correoB);
	public void removeChat(String idChat);
	public TOChat readChat(String idChat);
}