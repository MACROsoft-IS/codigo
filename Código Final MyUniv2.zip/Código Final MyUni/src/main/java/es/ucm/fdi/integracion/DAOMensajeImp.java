package es.ucm.fdi.integracion;

import es.ucm.fdi.datos.BDMemoria;

public class DAOMensajeImp implements DAOMensaje{
	

	private static BDMemoria<TOMensaje> bdMensajes; 
	
    public DAOMensajeImp() {
		DAOMensajeImp.bdMensajes = new BDMemoria<TOMensaje>();
	}

	public TOMensaje createMsj(String emisor, String mensaje, String idChat, String name) {
		//bdMensajes.insert(tMensaje, tMensaje.getSesionID());
		TOMensaje tMensaje = new TOMensaje(emisor, mensaje, idChat, name, bdMensajes.getIds().size());
		//System.out.println(tMensaje.toString());
		//chat.getMensajes().insert(tMensaje, tMensaje.getId());
		bdMensajes.insert(tMensaje, tMensaje.getId());
		return tMensaje;
	}

	public void removeUser(String idMensaje) {
		//chat.getMensajes().removeId(id);
		bdMensajes.removeId(idMensaje);
	}

	public TOMensaje read(String idMensaje) {
		//return chat.getMensajes().find(id);
		return bdMensajes.find(idMensaje);
	}
	

}
