package es.ucm.fdi;

import java.util.ArrayList;

import es.ucm.fdi.integracion.DAOChatImp;
import es.ucm.fdi.integracion.DAOFactory;
import es.ucm.fdi.integracion.DAOFactoryImp;
import es.ucm.fdi.integracion.DAOMensajeImp;
import es.ucm.fdi.integracion.DAOSesionImp;
import es.ucm.fdi.integracion.DAOUsuarioImp;
import es.ucm.fdi.integracion.TOUsuario;
import es.ucm.fdi.integracion.TOPendiente.tPendiente;
import es.ucm.fdi.negocio.ASGestionConocerImp;
import es.ucm.fdi.negocio.ASGestionCuentasImp;
import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class PruebaConocerGente extends TestCase {

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(PruebaConocerGente.class);
	}
	
	//da una persona aleatoria de las que queda por conocer
	public void testDarPersonaAleatoria(){
		
		DAOFactory fd = new DAOFactoryImp();

		DAOUsuarioImp daoUsuario = fd.generaDAOUsuario();
		DAOSesionImp daoSesion = fd.generaDAOSesion();
		DAOChatImp daoChat = fd.generaDAOChat();
		
		ASGestionCuentasImp as = new ASGestionCuentasImp(daoUsuario, daoSesion, daoChat);
		ASGestionConocerImp ac = new ASGestionConocerImp(daoUsuario, daoChat);
		
		as.crearCuenta("prueba", "correoprueba@ucm.es", "contrasena", "foto", "descripcion");
		TOUsuario usuarioAProbar = as.getUsuarioDAO().read("correoprueba@ucm.es");

		//creamos las cuentas
		for (int i = 0; i < 10; i++) {
			as.crearCuenta("nombre" + i, "correo" + i + "@ucm.es", "contrasena", "foto", "descripcion");
		}
		
		for (int i = 0; i < 10; i++) {
			
			TOUsuario usuarioAleatorio = ac.damePersonaValidaAleatoria(usuarioAProbar);
			
			assertTrue("El correo aleatorio extraido con correo " + usuarioAleatorio.getCorreo() + " no se encuentra en los conocidos de usuarioAprobar",
					!usuarioAProbar.getListaConocidos().contains(usuarioAleatorio.getCorreo()));
			
			as.getUsuarioDAO().anadirConocido(usuarioAProbar, usuarioAleatorio.getCorreo());
	
		}
		
		
		
	}
	
	//da usuarios pendientes de la lista de usuario pendientes validos para conocer ( que te han dado me gusta)
	public void testDarPesonasPendientes(){
		DAOFactory fd = new DAOFactoryImp();

		DAOUsuarioImp daoUsuario = fd.generaDAOUsuario();
		DAOSesionImp daoSesion = fd.generaDAOSesion();
		DAOChatImp daoChat = fd.generaDAOChat();
		
		ASGestionCuentasImp as = new ASGestionCuentasImp(daoUsuario, daoSesion, daoChat);
		ASGestionConocerImp ac = new ASGestionConocerImp(daoUsuario, daoChat);
		
		//correo sobre el que probar
		as.crearCuenta("prueba", "correoprueba@ucm.es", "contrasena", "foto", "descripcion");
		TOUsuario usuarioAProbar = as.getUsuarioDAO().read("correoprueba@ucm.es");

		for (int i = 0; i < 10; i++) {
			
			as.crearCuenta("nombre" + i, "correo" + i + "@ucm.es", "contrasena", "foto", "descripcion");
			as.getUsuarioDAO().anadirConocido(usuarioAProbar, "correo" + i + "@ucm.es");
			
			//solo metemos los pares
			if((2 + i) % 2 == 0){
				as.getUsuarioDAO().anadirPendiente(usuarioAProbar,  "correo" + i + "@ucm.es",  tPendiente.RECIBO);
			}
		}
		
		ArrayList<TOUsuario> listaUsuariosPendientes = new ArrayList<TOUsuario>();
		
		listaUsuariosPendientes = ac.dameUsuariosPendientes(usuarioAProbar);
		
		System.out.println(listaUsuariosPendientes.toString());
		
		assertTrue("En la lista de usuarios pendientes el usuario de prueba" + usuarioAProbar.getNombre() + " estan los correo pendientes: ",
				usuarioAProbar.getListaPendientes().size() == 5);

	}
	
	//aplicar una opcion a un usuario que no se ha conocido nunca
	public void testAplicarOpcion() {

		DAOFactory fd = new DAOFactoryImp();

		DAOUsuarioImp daoUsuario = fd.generaDAOUsuario();
		DAOSesionImp daoSesion = fd.generaDAOSesion();
		DAOChatImp daoChat = fd.generaDAOChat();

		ASGestionCuentasImp as = new ASGestionCuentasImp(daoUsuario, daoSesion, daoChat);

		int i = 0;

		// creamos las cuentas
		as.crearCuenta("conocedor", "conocedor@ucm.es", "contrasena1", "foto", "desc");
		as.crearCuenta("conocido1", "conocido1@ucm.es", "contrasena1", "foto", "desc");
		as.crearCuenta("desconocido", "desconocido@ucm.es", "contrasena1", "foto", "desc");
		as.crearCuenta("pendiente1", "pendiente1@ucm.es", "contrasena1", "foto", "desc");
		as.crearCuenta("pendiente2", "pendiente2@ucm.es", "contrasena1", "foto", "desc");
		as.crearCuenta("desconocido2", "desconocido2@ucm.es", "contrasena1", "foto", "desc");

		TOUsuario pendiente1 = as.getUsuarioDAO().read("pendiente1@ucm.es");
		as.getUsuarioDAO().anadirPendiente(pendiente1, "pendiente2@ucm.es", tPendiente.MANDO);

		TOUsuario conocedor = as.getUsuarioDAO().read("conocedor@ucm.es");

		as.getUsuarioDAO().anadirPendiente(conocedor, "pendiente2@ucm.es", tPendiente.RECIBO);
		as.getUsuarioDAO().anadirPendiente(conocedor, "pendiente1@ucm.es", tPendiente.MANDO);
		as.getUsuarioDAO().anadirConocido(conocedor, "conocido1@ucm.es");

		TOUsuario desconocido = as.getUsuarioDAO().read("desconocido@ucm.es");
		TOUsuario desconocido2 = as.getUsuarioDAO().read("desconocido2@ucm.es");

		assertFalse("Desconocido ya esta en la lista de conocedor",
				conocedor.getListaConocidos().contains("desconocido@ucm.es"));

		// Este es el case 1 resultado del metodo "muestra" de
		// ASGestionConocerImp. REPRESENTA EL SI DEL MUESTRA.

		while (i < desconocido.getListaPendientes().size()
				&& !desconocido.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("conocedor@ucm.es")) {
			++i;
		}

		assertFalse("Conocedor ya esta en la lista de pendientes", i < desconocido.getListaPendientes().size());

		i = 0;
		while (i < conocedor.getListaPendientes().size()
				&& !conocedor.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("desconocido@ucm.es")) {
			++i;
		}
		assertFalse("Desconocido ya esta en la lista de pendientes", i < conocedor.getListaPendientes().size());

		as.getUsuarioDAO().anadirPendiente(conocedor, "desconocido@ucm.es", tPendiente.MANDO);

		as.getUsuarioDAO().anadirPendiente(desconocido, "conocedor@ucm.es", tPendiente.RECIBO);

		as.getUsuarioDAO().anadirConocido(conocedor, "desconocido@ucm.es");

		i = 0;
		while (i < desconocido.getListaPendientes().size()
				&& !desconocido.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("conocedor@ucm.es")) {
			++i;
		}

		assertTrue("Conocedor no esta en la lista de pendientes", i < desconocido.getListaPendientes().size());

		i = 0;
		while (i < conocedor.getListaPendientes().size()
				&& !conocedor.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("desconocido@ucm.es")) {
			++i;
		}

		assertTrue("Desconocido no esta en la lista de conocidos",
				conocedor.getListaConocidos().contains("desconocido@ucm.es"));

		assertTrue("Desconocido no esta en la lista de pendientes", i < conocedor.getListaPendientes().size());

		// Este es el case 2 resultado del metodo "muestra" de
		// ASGestionConocerImp. REPRESENTA EL NO DEL MUESTRA.

		assertFalse("Desconocido ya esta en la lista de conocidos",
				conocedor.getListaConocidos().contains("desconocido2@ucm.es"));
		assertFalse("Conocedor ya esta en la lista de conocidos",
				desconocido2.getListaConocidos().contains("conocedor@ucm.es"));

		as.getUsuarioDAO().anadirConocido(conocedor, "desconocido2@ucm.es");
		as.getUsuarioDAO().anadirConocido(desconocido2, "conocedor@ucm.es");

		assertTrue("Desconocido no se ha añadido a la lista de conocidos",
				conocedor.getListaConocidos().contains("desconocido2@ucm.es"));
		assertTrue("Conocedor no se ha añadido a la lista de conocidos",
				desconocido2.getListaConocidos().contains("conocedor@ucm.es"));

	}

	//aplicar una opcion a un usuario que ya se ha conocido previamente y que dio me gusta
	public void testAplicarOpcionPendiente() {

		DAOFactory fd = new DAOFactoryImp();
		DAOUsuarioImp daoUsuario = fd.generaDAOUsuario();
		DAOSesionImp daoSesion = fd.generaDAOSesion();
		DAOChatImp daoChat = fd.generaDAOChat();

		ASGestionCuentasImp as = new ASGestionCuentasImp(daoUsuario, daoSesion, daoChat);

		int i = 0;

		as.crearCuenta("conocedorP", "conocedorP@ucm.es", "contrasena1", "foto", "desc");
		as.crearCuenta("conocido1P", "conocido1P@ucm.es", "contrasena1", "foto", "desc");
		as.crearCuenta("pendiente1P", "pendiente1P@ucm.es", "contrasena1", "foto", "desc");
		as.crearCuenta("pendiente2P", "pendiente2P@ucm.es", "contrasena1", "foto", "desc");

		// Este es el case 1 resultado del metodo "muestraPendiente" de
		// ASGestionConocerImp. REPRESENTA EL SI DEL MUESTRAPENDIENTE.

		TOUsuario pendiente2P = as.getUsuarioDAO().read("pendiente2P@ucm.es");
		as.getUsuarioDAO().anadirPendiente(pendiente2P, "conocedorP@ucm.es", tPendiente.MANDO);

		TOUsuario pendiente1P = as.getUsuarioDAO().read("pendiente1P@ucm.es");
		as.getUsuarioDAO().anadirPendiente(pendiente1P, "pendiente2P@ucm.es", tPendiente.MANDO);
		as.getUsuarioDAO().anadirPendiente(pendiente1P, "conocedorP@ucm.es", tPendiente.RECIBO);

		TOUsuario conocedorP = as.getUsuarioDAO().read("conocedorP@ucm.es");
		as.getUsuarioDAO().anadirConocido(conocedorP, "conocido1P@ucm.es");
		as.getUsuarioDAO().anadirPendiente(conocedorP, "pendiente1P@ucm.es", tPendiente.MANDO);
		as.getUsuarioDAO().anadirPendiente(conocedorP, "pendiente2P@ucm.es", tPendiente.RECIBO);

		while (i < conocedorP.getListaPendientes().size()
				&& !conocedorP.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("pendiente1P@ucm.es")) {
			++i;
		}

		assertTrue("Pendiente no esta en la lista de pendientes", i < conocedorP.getListaPendientes().size());

		i = 0;
		while (i < pendiente1P.getListaPendientes().size()
				&& !pendiente1P.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("conocedorP@ucm.es")) {
			++i;
		}

		assertTrue("Conocedor no esta en la lista de pendientes", i < pendiente1P.getListaPendientes().size());

		// No hacemos un assert de los chats porque ya estan hechos en la prueba
		// PruebaChat.

		as.getUsuarioDAO().añadirChatIdVector(conocedorP, conocedorP.getCorreo() + "/" + pendiente1P.getCorreo());

		as.getUsuarioDAO().añadirChatIdVector(pendiente1P, conocedorP.getCorreo() + "/" + conocedorP.getCorreo());

		as.getUsuarioDAO().anadirConocido(conocedorP, "pendiente1P@ucm.es");

		as.getUsuarioDAO().eliminarPendiente(conocedorP, "pendiente1P@ucm.es");

		as.getUsuarioDAO().eliminarPendiente(pendiente1P, "conocedorP@ucm.es");

		i = 0;
		while (i < pendiente1P.getListaPendientes().size()
				&& !pendiente1P.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("conocedorP@ucm.es")) {
			++i;
		}

		assertFalse("Conocedor sigue estando en la lista de pendientes", i < pendiente1P.getListaPendientes().size());

		i = 0;
		while (i < conocedorP.getListaPendientes().size()
				&& !conocedorP.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("pendiente1P@ucm.es")) {
			++i;
		}

		assertFalse("Pendiente sigue estando en la lista de pendientes", i < conocedorP.getListaPendientes().size());

		// Este es el case 2 resultado del metodo "muestraPendiente" de
		// ASGestionConocerImp. REPRESENTA EL NO DEL MUESTRAPENDIENTE.
		i = 0;
		while (i < conocedorP.getListaPendientes().size()
				&& !conocedorP.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("pendiente2P@ucm.es")) {
			++i;
		}

		assertTrue("Pendiente no esta en la lista de pendientes", i < conocedorP.getListaPendientes().size());

		i = 0;
		while (i < pendiente2P.getListaPendientes().size()
				&& !pendiente2P.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("conocedorP@ucm.es")) {
			++i;
		}

		assertTrue("Conocedor no esta en la lista de pendientes", i < pendiente2P.getListaPendientes().size());

		assertFalse("Pendiente ya esta en la lista de conocidos",
				conocedorP.getListaConocidos().contains("pendiente2P@ucm.es"));

		as.getUsuarioDAO().anadirConocido(conocedorP, "pendiente2P@ucm.es");

		as.getUsuarioDAO().eliminarPendiente(conocedorP, "pendiente2P@ucm.es");
		as.getUsuarioDAO().eliminarPendiente(pendiente2P, "conocedorP@ucm.es");

		assertTrue("Pendiente no esta en la lista de conocidos",
				conocedorP.getListaConocidos().contains("pendiente2P@ucm.es"));

		i = 0;
		while (i < pendiente1P.getListaPendientes().size()
				&& !pendiente1P.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("conocedorP@ucm.es")) {
			++i;
		}

		assertFalse("Conocedor sigue estando en la lista de pendientes", i < pendiente1P.getListaPendientes().size());

		i = 0;
		while (i < conocedorP.getListaPendientes().size()
				&& !conocedorP.getListaPendientes().get(i).getCorreo().equalsIgnoreCase("pendiente1P@ucm.es")) {
			++i;
		}
		assertFalse("Pendiente sigue estando en la lista de pendientes", i < conocedorP.getListaPendientes().size());
	}

}
